package com.library;

public class Book {
    private String title;
    private String author;
    private String isbn;
    private String genre;
    private int totalQuantity;
    private String id;

    public Book(String title, String author, String isbn, String genre, int totalQuantity, String id) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.totalQuantity = totalQuantity;
        this.id = id;
    }

    public Book(String title, String author, String isbn, String genre, int totalQuantity) {
        this(title, author, isbn, genre, totalQuantity, java.util.UUID.randomUUID().toString());
    }

    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public int getTotalQuantity() { return totalQuantity; }
    public void setTotalQuantity(int q) { this.totalQuantity = q; }

    public String getId() { return id; }

    @Override
    public String toString() {
        return String.format("Book[id=%s,title=%s,author=%s,isbn=%s,genre=%s,total=%d]", id, title, author, isbn, genre, totalQuantity);
    }
}
