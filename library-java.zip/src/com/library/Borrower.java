package com.library;

public class Borrower {
    private String name;
    private String contact;
    private String membershipId;
    private String id;

    public Borrower(String name, String contact, String membershipId) {
        this.name = name;
        this.contact = contact;
        this.membershipId = membershipId;
        this.id = java.util.UUID.randomUUID().toString();
    }

    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getMembershipId() { return membershipId; }

    public String getId() { return id; }

    @Override
    public String toString() {
        return String.format("Borrower[id=%s,name=%s,membershipId=%s,contact=%s]", id, name, membershipId, contact);
    }
}
