package com.library;

import java.time.LocalDate;

public class LoanRecord {
    private String bookId;
    private String borrowerMembershipId;
    private LocalDate borrowedOn;
    private LocalDate dueDate;
    private LocalDate returnedOn;

    public LoanRecord(String bookId, String borrowerMembershipId, LocalDate borrowedOn, LocalDate dueDate) {
        this.bookId = bookId;
        this.borrowerMembershipId = borrowerMembershipId;
        this.borrowedOn = borrowedOn;
        this.dueDate = dueDate;
    }

    public String getBookId() { return bookId; }
    public String getBorrowerMembershipId() { return borrowerMembershipId; }
    public LocalDate getBorrowedOn() { return borrowedOn; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDate getReturnedOn() { return returnedOn; }
    public void setReturnedOn(LocalDate d) { this.returnedOn = d; }

    public boolean isOverdue() {
        if (returnedOn != null) return returnedOn.isAfter(dueDate);
        return LocalDate.now().isAfter(dueDate);
    }

    @Override
    public String toString() {
        return String.format("Loan[bookId=%s,member=%s,borrowed=%s,due=%s,returned=%s]",
            bookId, borrowerMembershipId, borrowedOn, dueDate, returnedOn);
    }
}
