package com.library;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class Library {
    private Map<String, Book> books = new HashMap<>(); // bookId -> Book
    private Map<String, Borrower> borrowers = new HashMap<>(); // membershipId -> Borrower
    private Map<String, Integer> available = new HashMap<>(); // bookId -> available copies
    private List<LoanRecord> loans = new ArrayList<>();

    // Book management
    public Book addBook(String title, String author, String isbn, String genre, int quantity) {
        Book b = new Book(title, author, isbn, genre, quantity);
        books.put(b.getId(), b);
        available.put(b.getId(), quantity);
        return b;
    }

    public void updateBook(String bookId, String title, String author, Integer quantity) {
        Book b = books.get(bookId);
        if (b == null) throw new RuntimeException("Book not found: " + bookId);
        if (title != null) b.setTitle(title);
        if (author != null) b.setAuthor(author);
        if (quantity != null) {
            int lentOut = b.getTotalQuantity() - available.getOrDefault(bookId, 0);
            if (quantity < lentOut) throw new RuntimeException("Cannot set total quantity less than currently lent out copies");
            b.setTotalQuantity(quantity);
            available.put(bookId, quantity - lentOut);
        }
    }

    public void removeBook(String bookId) {
        int lentOut = books.containsKey(bookId) ? books.get(bookId).getTotalQuantity() - available.getOrDefault(bookId, 0) : 0;
        if (lentOut > 0) throw new RuntimeException("Cannot remove book; copies are currently lent out");
        books.remove(bookId);
        available.remove(bookId);
    }

    // Borrower management
    public Borrower addBorrower(String name, String contact, String membershipId) {
        if (borrowers.containsKey(membershipId)) throw new RuntimeException("Membership ID already exists: " + membershipId);
        Borrower br = new Borrower(name, contact, membershipId);
        borrowers.put(membershipId, br);
        return br;
    }

    public void updateBorrower(String membershipId, String name, String contact) {
        Borrower br = borrowers.get(membershipId);
        if (br == null) throw new RuntimeException("Borrower not found: " + membershipId);
        if (name != null) br.setName(name);
        if (contact != null) br.setContact(contact);
    }

    public void removeBorrower(String membershipId) {
        boolean hasActiveLoan = loans.stream().anyMatch(l -> l.getBorrowerMembershipId().equals(membershipId) && l.getReturnedOn() == null);
        if (hasActiveLoan) throw new RuntimeException("Borrower has active loans; cannot remove");
        borrowers.remove(membershipId);
    }

    // Borrow & return
    public LoanRecord borrowBook(String membershipId, String bookId, int days) {
        Borrower br = borrowers.get(membershipId);
        if (br == null) throw new RuntimeException("Borrower not found: " + membershipId);
        Book b = books.get(bookId);
        if (b == null) throw new RuntimeException("Book not found: " + bookId);
        int avail = available.getOrDefault(bookId, 0);
        if (avail <= 0) throw new RuntimeException("Book not available");
        available.put(bookId, avail - 1);
        LocalDate now = LocalDate.now();
        LoanRecord lr = new LoanRecord(bookId, membershipId, now, now.plusDays(days));
        loans.add(lr);
        return lr;
    }

    public void returnBook(String membershipId, String bookId) {
        Optional<LoanRecord> loan = loans.stream()
            .filter(l -> l.getBookId().equals(bookId) && l.getBorrowerMembershipId().equals(membershipId) && l.getReturnedOn() == null)
            .findFirst();
        if (!loan.isPresent()) throw new RuntimeException("Active loan not found for given borrower and book");
        LoanRecord lr = loan.get();
        lr.setReturnedOn(LocalDate.now());
        available.put(bookId, available.getOrDefault(bookId, 0) + 1);
    }

    // Search and availability
    public List<Book> searchByTitle(String titleQuery) {
        String q = titleQuery.toLowerCase();
        return books.values().stream().filter(b -> b.getTitle().toLowerCase().contains(q)).collect(Collectors.toList());
    }

    public List<Book> searchByAuthor(String authorQuery) {
        String q = authorQuery.toLowerCase();
        return books.values().stream().filter(b -> b.getAuthor().toLowerCase().contains(q)).collect(Collectors.toList());
    }

    public List<Book> searchByGenre(String genreQuery) {
        String q = genreQuery.toLowerCase();
        return books.values().stream().filter(b -> b.getGenre().toLowerCase().contains(q)).collect(Collectors.toList());
    }

    public int availableCopies(String bookId) {
        return available.getOrDefault(bookId, 0);
    }

    public List<LoanRecord> listOverdue() {
        return loans.stream().filter(l -> l.getReturnedOn() == null && l.isOverdue()).collect(Collectors.toList());
    }

    // Utilities
    public Optional<Book> getBook(String bookId) { return Optional.ofNullable(books.get(bookId)); }
    public Optional<Borrower> getBorrower(String membershipId) { return Optional.ofNullable(borrowers.get(membershipId)); }
}
